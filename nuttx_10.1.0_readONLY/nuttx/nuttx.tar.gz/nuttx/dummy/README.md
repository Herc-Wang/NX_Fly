This directory exists to hold an empty Kconfig which is used
when no nuttx/external is present.

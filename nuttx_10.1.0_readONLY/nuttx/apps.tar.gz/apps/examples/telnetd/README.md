# Examples / `telnetd` Telnet Daemon

This directory contains a functional port of the tiny uIP shell. In the NuttX
environment, the NuttShell (at `apps/nshlib`) supersedes this tiny shell and
also supports telnetd.

This example is retained here for reference purposes only.

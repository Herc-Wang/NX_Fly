<?php
echo json_encode($_POST);
?>
